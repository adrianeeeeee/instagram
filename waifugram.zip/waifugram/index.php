<?php 
session_start();
if(!isset($_SESSION['login'])) {
  header("location:index.php?pesan=logindulu");
}

include "koneksi.php";


if (isset($_POST["cari"])) {
  $keyword = $_POST["keyword"];

  // Query pencarian berdasarkan caption
  $sql = "SELECT * FROM post WHERE caption LIKE '%$keyword%'";
  $query = mysqli_query($koneksi, $sql);
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Waifugram</title>
  <link rel="shortcut icon" href="favicon.ico">
  <link rel="stylesheet" href="sidebar/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;700&display=swap" rel="stylesheet">
    
<style>
  body{
  background-image: url(img/bgblur.jpg);
  background-size: cover;
  background-repeat: no-repeat;
  background-attachment: fixed;
  font-family: 'Poppins';
  /* backdrop-filter: blur(10px); */
  }
.zoom {
  overflow:hidden;
  margin: 0 auto;
}
.zoom img{
  width: 100%;
  transition: 0.5s all ease-in-out;
}
.zoom:hover img{
  transform:scale(1.3);
  cursor: pointer;
}


</style>

</head>
<body>

<!-- <nav class="navbar navbar-expand-lg fixed-top" style="background-color:#F675A8;">
  <div class="container-fluid">
    <img src="img/waifugram.png" style="width: 200px;" alt="">
    <a class="navbar-brand text-light ms-4" href="#"></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">  
      </ul>
      <button class="btn btn-primary me-4" data-bs-toggle="modal" data-bs-target="#exampleModal"><i class="fa-solid fa-plus"></i></button>
      <a class="btn btn-danger float-end" href="logout.php"><i class="fa-solid fa-right-from-bracket"></i></a>
    </div>
  </div>
</nav> -->

<!-- <a class="sticky-￼
top" type="button" data-bs-toggle="offcanvas" data-bs-target="#staticBackdrop" aria-controls="staticBackdrop">
  <img src="img/waifugram.png" width="200px"  alt="">
</a>

<div class="offcanvas offcanvas-start" style="background-image:linear-gradient(#222831,#0079FF);" data-bs-backdrop="static" tabindex="-1" id="staticBackdrop" aria-labelledby="staticBackdropLabel">
  <div class="offcanvas-header">
  <img src="img/waifugram.png" style="width: 200px;" alt="">
    <button type="button" class="btn-close text-light" data-bs-dismiss="offcanvas" aria-label="Close"></button>
  </div>
  <div class="offcanvas-body">
    <div><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    <button class="btn btn-lg me-4" data-bs-toggle="modal" data-bs-target="#tambahModal"><i class="fa-solid fa-plus text-light"></i></button><br><br>
    <a class="btn btn-lg me-4" href="logout.php"><i class="fa-solid fa-right-from-bracket text-light"></i></a>
    </div>
  </div>
</div>

</div> -->

<!-- Sidebar -->
<aside class="sidebar"  style="background-color:#000000;">
        <header class="sidebar-header">
            <img src="img/brand.png" style="cursor:pointer;" onclick="window.location.href ='#'"; width="125px" class="logo-img">
            <!-- <i class="logo-icon bx bxl-instagram"></i> -->
        </header>

        <nav>
            <button class="text-light" onclick="window.location.href ='index.php'";>
                <span>
                <i class="fa-solid fa-house text-light" ></i>
                <span>Beranda</span>
                </span>
            </button>

            <button class="btn btn-lg text-light" data-bs-toggle="modal" data-bs-target="#cariModal">
                <span>
                    <i class="fa-solid fa-magnifying-glass text-light" ></i>
                    <span>Cari</span>
                </span>
            </button>
<!-- 
            <button class="text-light">
                <span>
                    <i class="fa-solid fa-compass text-light" ></i>
                    <span>Jelajahi</span>
                </span>
            </button>

            <button class="text-light">
                <span>
                    <i class="fa-solid fa-comment-dots text-light" >
                        <span>80</span>
                    </i>
                    <span>Pesan</span>
                </span>
            </button>

            <button class="text-light">
                <span>
                    <i class="fa-solid fa-heart text-light" >
                        <em></em>
                    </i>
                    <span>Notifikasi</span>
                </span>
            </button> -->

            <button class="btn btn-lg text-light" data-bs-toggle="modal" data-bs-target="#buatModal"><span><i class="fa-regular fa-square-plus text-light"></i><span>Buat</span></span></button>
            
            <button class="btn btn-lg text-light" onclick="window.location.href ='logout.php';" ><span><i class="fa-solid fa-arrow-right-from-bracket  text-light"></i><span>Logout</span></span></button>


        </nav>


    </aside>

    <!-- Modal Cari-->
  <div class="modal fade modal-lg" id="cariModal" tabindex="-1" aria-labelledby="cariModal" aria-hidden="true" >
    <div class="modal-dialog" >
      <div class="modal-content">
        <div class="modal-header">
          <h1 class="modal-title fs-5" id="cariModal">Cari</h1>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
  <div class="modal-body">
      <form action="" method="post">
          <input class = "form-control" type="text" name="keyword" size="40" autofocus
          placeholder="masukkan keyword pencarian.." autocomplete="off"><br>
    
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Kembali</button>
        <input type="submit" name="cari" class="btn text-light " style="background-color:#F11A7B;" value="Cari">
      </form>
      </div>
    </div>
  </div>
</div>

</div>
<div class="container">
  <!-- Modal Buat-->
  <div class="modal fade" id="buatModal" tabindex="-1" aria-labelledby="buatModal" aria-hidden="true" >
    <div class="modal-dialog" >
      <div class="modal-content">
        <div class="modal-header">
          <h1 class="modal-title fs-5" id="buatModal">Form Buat</h1>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
  <div class="modal-body">
      <form action="prosestambah.php" method="post" enctype="multipart/form-data">
        <label for="">Foto</label><br>
          <input class = "form-control" type="file" name="foto" id="" required><br>
          <label for="">Caption</label><br>
          <input class = "form-control" type="text" name="caption" id="" autocomplete="off"><br>
        <label for="">Lokasi</label><br>
        <input class = "form-control" type="text" name="lokasi" id="" autocomplete="off"><br><br>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Kembali</button>
        <input type="submit" name="Simpan" class="btn text-light" style="background-color:#F11A7B;" value="Simpan">
      </form>
      </div>
    </div>
  </div>
</div>

</div>

<!-- Card Content -->
<div class="container" >
<?php 
  if (isset($_POST["cari"])) {
    if (mysqli_num_rows($query) > 0) {
// $sql ="SELECT * FROM post";
// $query = mysqli_query($koneksi, $sql);

while ($row = mysqli_fetch_assoc($query)) : ?>
<div class="padding" style="padding-top:6rem; padding-bottom:6rem;" >
    <div class="card"style="margin-left:auto; margin-right:auto; width: 30%; " >
      <div class="zoom">
    <!-- <div class="card-body" style="background-image:linear-gradient(#fff,#0079FF); border-radius:10px;"> -->
    <tr>
    <td><img class="card-img-top mb-3 " src="insta/<?= $row['foto'] ?>" alt="" style="height:300px;"></td><br><br><br>
    <div class="grid-group grid-group-flush">
    <div class="grid-group-item text-dark" style="margin-left:20px;">
        <th> </th>
        <td><?=$row['caption']?></td>  
      </div>
      <div class="grid-group-item text-dark" style="margin-left:20px;">
        <th> </th>
        <td><?=$row['lokasi']?></td> 
    </div>
  </div><br><br>
<td>
  <center>
    <a class="btn btn-lg " href="hapus.php?no=<?= $row['no'] ?>"><i class="fa-solid fa-trash text-secondary" onclick="alert('Apakah kamu yakin?')"></i></a>
    <button class="btn btn-lg "  data-bs-toggle="modal" data-bs-target="#editModal<?=$row['no']?>"><i class="fa-solid fa-pen-to-square" style="color:#F11A7B;"></i></button>
  </center>   
</td>
</tr>      
</div>
</div> 
</div>

<!-- Modal Edit-->
<div class="modal fade" id="editModal<?=$row['no']?>" tabindex="-1" aria-labelledby="editModal<?=$row['no']?>" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="editModalLabel">Form Edit</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form action="prosesedit.php" method="post" enctype="multipart/form-data">
          <input type="hidden" name="no" value="<?= $row['no']; ?>">
          <input type="hidden" name="foto_lama" value="<?= $row['foto']; ?>">
          <label for="">Foto</label><br>
          <input class = "form-control"type="file" name="foto" id="" value="<?=$row['foto']; ?>" ><br>
          <img src="insta/<?= $row['foto'] ?>" width="370" alt="" ><br><br>
          <label for="">Caption</label><br>
          <input class = "form-control" type="text" name="caption" id=""  value="<?= $row['caption']; ?>"autocomplete="off"><br>
          <label for="" >Lokasi</label><br>
          <input class = "form-control" type="text" name="lokasi" id=""  value="<?= $row['lokasi']; ?>" autocomplete="off"><br><br>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Kembali</button>
          <input type="submit" name="Simpan" class="btn text-light" style="background-color:#F11A7B;" value="Simpan">
        </form>
    </div>
  </div>
</div>
</div>
</div>

<?php endwhile;

        } else {
            // Tampilkan pesan jika tidak ada hasil yang ditemukan
        echo '<script type="text/javascript">alert("Data tidak ditemukan"); window.location.href = "index.php";</script>' ;
        }
    } else {
        // Tampilkan semua data jika belum ada pencarian
        $sql_all = "SELECT * FROM post ORDER BY no DESC";
        $query_all = mysqli_query($koneksi, $sql_all);

        while ($row = mysqli_fetch_assoc($query_all)) :
        ?>

        

<div class="padding" style="padding-top:6rem; padding-bottom:6rem;" >
    <div class="card"style="margin-left:auto; margin-right:auto; width: 30%; " >
      <div class="zoom">
    <!-- <div class="card-body" style="background-image:linear-gradient(#fff,#0079FF); border-radius:10px;"> -->
    <tr>
    <td><img class="card-img-top mb-3 " src="insta/<?= $row['foto'] ?>" alt="" style="height:300px;"></td><br><br><br>
    <div class="grid-group grid-group-flush">
    <div class="grid-group-item text-dark" style="margin-left:20px;">
        <th> </th>
        <td><?=$row['caption']?></td>  
      </div>
      <div class="grid-group-item text-dark" style="margin-left:20px;">
        <th> </th>
        <td><?=$row['lokasi']?></td> 
    </div>
  </div><br><br>
<td>
  <center>
    <a class="btn btn-lg " href="hapus.php?no=<?= $row['no'] ?>"><i class="fa-solid fa-trash text-secondary" onclick="alert('Apakah kamu yakin?')"></i></a>
    <button class="btn btn-lg "  data-bs-toggle="modal" data-bs-target="#editModal<?=$row['no']?>"><i class="fa-solid fa-pen-to-square" style="color:#F11A7B;"></i></button>
  </center>   
</td>
</tr>      
</div>
</div> 
</div>

<!-- Modal Edit-->
<div class="modal fade" id="editModal<?=$row['no']?>" tabindex="-1" aria-labelledby="editModal<?=$row['no']?>" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="editModalLabel">Form Edit</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form action="prosesedit.php" method="post" enctype="multipart/form-data">
          <input type="hidden" name="no" value="<?= $row['no']; ?>">
          <input type="hidden" name="foto_lama" value="<?= $row['foto']; ?>">
          <label for="">Foto</label><br>
          <input class = "form-control"type="file" name="foto" id="" value="<?=$row['foto']; ?>" ><br>
          <img src="insta/<?= $row['foto'] ?>" width="370" alt="" ><br><br>
          <label for="">Caption</label><br>
          <input class = "form-control" type="text" name="caption" id=""  value="<?= $row['caption']; ?>"autocomplete="off"><br>
          <label for="" >Lokasi</label><br>
          <input class = "form-control" type="text" name="lokasi" id=""  value="<?= $row['lokasi']; ?>" autocomplete="off"><br><br>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Kembali</button>
          <input type="submit" name="Simpan" class="btn text-light" style="background-color:#F11A7B;" value="Simpan">
        </form>
    </div>
  </div>
</div>
</div>
</div>

<?php endwhile; } ?>

<!-- JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
<script src="https://kit.fontawesome.com/4865b1e9c6.js" crossorigin="anonymous"></script>
<script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/jquery-migrate-3.0.0.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  <script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
</body>
</html>


