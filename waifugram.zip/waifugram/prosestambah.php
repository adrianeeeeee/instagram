<?php 
include "koneksi.php";
require "functions.php";

if (isset($_POST['Simpan'])) {

    $caption = $_POST['caption'];
    $lokasi = $_POST['lokasi'];
    $foto = upload();

    $sql = "INSERT INTO post (foto, caption, lokasi) VALUES ('$foto','$caption','$lokasi')";
    $query = mysqli_query($koneksi,$sql);

    if($query) {
        header("location:index.php?tambah=sukses");
    } else {
        header("location:index.php?tambah=gagal");
    }
}



?>