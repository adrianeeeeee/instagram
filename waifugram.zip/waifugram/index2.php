<?php
session_start();
if (!isset($_SESSION['login'])) {
    header("location:index.php?pesan=logindulu");
}

include "koneksi.php";

if (isset($_POST["cari"])) {
    $keyword = $_POST["keyword"];

    // Query pencarian berdasarkan caption
    $sql = "SELECT * FROM post WHERE caption LIKE '%$keyword%'";
    $query = mysqli_query($koneksi, $sql);
}
?>



<div class="modal fade modal-lg bg" style="background-color:#000000;" id="cariModal" tabindex="-1" aria-labelledby="cariModal" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="cariModal">Cari</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form action="" method="post">
                    <input class="form-control" type="text" name="keyword" size="40" autofocus
                        placeholder="Masukkan caption pencarian.." autocomplete="off"><br>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Kembali</button>
                        <input type="submit" name="cari" class="btn text-light" style="background-color:#F11A7B;" value="Cari">
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Card Content -->
<div class="container">
    <?php
    if (isset($_POST["cari"])) {
        if (mysqli_num_rows($query) > 0) {
            while ($row = mysqli_fetch_assoc($query)) :
    ?>
                <div class="padding" style="padding-top:6rem; padding-bottom:6rem;">
                    <!-- Tampilkan data hasil pencarian -->
                    <div class="card" style="margin-left:auto; margin-right:auto; width: 30%;">
                        <div class="zoom">
                            <!-- Tampilkan data post -->
                            <tr>
                                <td><img class="card-img-top mb-3 " src="insta/<?= $row['foto'] ?>" alt=""
                                        style="height:300px;"></td><br><br><br>
                                <div class="grid-group grid-group-flush">
                                    <div class="grid-group-item text-dark" style="margin-left:20px;">
                                        <th> </th>
                                        <td><?= $row['caption'] ?></td>
                                    </div>
                                    <div class="grid-group-item text-dark" style="margin-left:20px;">
                                        <th> </th>
                                        <td><?= $row['lokasi'] ?></td>
                                    </div>
                                </div><br><br>
                                <td>
                                    <center>
                                        <button class="btn btn-lg " data-bs-toggle="modal"
                                            data-bs-target="#editModal<?= $row['no'] ?>"><i
                                                class="fa-solid fa-pen-to-square" style="color:#F11A7B;"></i></button>
                                        <a class="btn btn-lg " href="hapus.php?no=<?= $row['no'] ?>"><i
                                                class="fa-solid fa-trash text-secondary"
                                                onclick="alert('Apakah kamu yakin?')"></i></a>
                                    </center>
                                </td>
                            </tr>
                        </div>
                    </div>
                </div>
    <?php
            endwhile;
        } else {
            // Tampilkan pesan jika tidak ada hasil yang ditemukan
            echo "<p>Tidak ada hasil yang ditemukan.</p>";
        }
    } else {
        // Tampilkan semua data jika belum ada pencarian
        $sql_all = "SELECT * FROM post";
        $query_all = mysqli_query($koneksi, $sql_all);

        while ($row = mysqli_fetch_assoc($query_all)) :
    ?>
            <div class="padding" style="padding-top:6rem; padding-bottom:6rem;">
                <!-- Tampilkan data post -->
                <div class="card" style="margin-left:auto; margin-right:auto; width: 30%;">
                    <div class="zoom">
                        <!-- Tampilkan data post -->
                        <tr>
                            <td><img class="card-img-top mb-3 " src="insta/<?= $row['foto'] ?>" alt=""
                                    style="height:300px;"></td><br><br><br>
                            <div class="grid-group grid-group-flush">
                                <div class="grid-group-item text-dark" style="margin-left:20px;">
                                    <th> </th>
                                    <td><?= $row['caption'] ?></td>
                                </div>
                                <div class="grid-group-item text-dark" style="margin-left:20px;">
                                    <th> </th>
                                    <td><?= $row['lokasi'] ?></td>
                                </div>
                            </div><br><br>
                            <td>
                                <center>
                                    <button class="btn btn-lg " data-bs-toggle="modal"
                                        data-bs-target="#editModal<?= $row['no'] ?>"><i
                                            class="fa-solid fa-pen-to-square" style="color:#F11A7B;"></i></button>
                                    <a class="btn btn-lg " href="hapus.php?no=<?= $row['no'] ?>"><i
                                            class="fa-solid fa-trash text-secondary"
                                            onclick="alert('Apakah kamu yakin?')"></i></a>
                                </center>
                            </td>
                        </tr>
                    </div>
                </div>
            </div>
    <?php
        endwhile;
    }
    ?>
</div>
